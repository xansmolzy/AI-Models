import os
#os.system('gst-launch-1.0 nvarguscamerasrc num-buffers=1 ! nvvidconv ! \'video/x-raw(memory:NVMM), format=I420\' ! nvjpegenc ! filesink location=test.jpeg')
from keras.models import load_model
import numpy as np
import pandas as pd
import cv2
from collections import Counter

SIZEXYZ = [224, 224, 3]
face_types = 'Padron pepper','Carolina reaper pepper', 'habanero pepper', 'Aji Dulce pepper', 'Madame jeanette pepper', 'jalapeno pepper', 'cayenne pepper', 'bell pepper', 'naga pepper', 'brain strain pepper'

VGG16_MOD  = load_model(os.path.dirname(os.path.realpath(__file__)) + '/' + 'VGGMOD.hdf5') #0.8 ACC
RESNET_MOD = load_model(os.path.dirname(os.path.realpath(__file__)) + '/' + 'RSNET.hdf5')  #0.6 ACC
#INCEP_MOD  = load_model('INCV3.hdf5')  # SHIT

def mode(my_list):
    ct = Counter(my_list)
    max_value = max(ct.values())
    return ([key for key, value in ct.items() if value == max_value])

img = cv2.resize(cv2.imread(os.path.dirname(os.path.realpath(__file__)) + '/' + 'test3.jpg'),(SIZEXYZ[0], SIZEXYZ[1]))
print(os.path.dirname(os.path.realpath(__file__)) + '/' + 'test3.jpg')
img_normalized = img
vgg16_image_prediction = np.argmax(VGG16_MOD.predict(np.array([img_normalized])))
resnet_50_image_prediction = np.argmax(RESNET_MOD.predict(np.array([img_normalized])))
#InceptionV3_image_prediction = np.argmax(INCEP_MOD.predict(np.array([img_normalized])))
#print(InceptionV3_image_prediction)
image_prediction = mode([vgg16_image_prediction, resnet_50_image_prediction])
print(image_prediction)
for item in image_prediction:
    print(face_types[item])