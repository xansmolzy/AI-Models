import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
import os
from sklearn.preprocessing import MinMaxScaler, StandardScaler

import warnings
warnings.filterwarnings('ignore')

from scipy import stats

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import Sequential, layers, callbacks
from tensorflow.keras.layers import Dense, LSTM, Dropout, GRU, Bidirectional


# Set random seed to get the same result after each time running the code
tf.random.set_seed(42)
print(os.path.dirname(os.path.realpath(__file__)) + "/co2.csv")
data = pd.read_csv(os.path.dirname(os.path.realpath(__file__)) + "/co2.csv", sep = ',', parse_dates=['DateTime'])
data.drop(['percent'], axis = 1,  inplace = True)
data['DateTime'] = pd.to_datetime(data['DateTime'].dt.strftime("%d-%m-%Y %H:%M:%S"), utc=True).dt.tz_localize(None)
print(data.head())
data.index = data['DateTime']
data = data.resample('H', label='left').mean()
print(data.head())
#data.drop(['DateTime'], axis = 1,  inplace = True)
data = data.dropna()

# Select the target
df = data.rename(columns = {'co2':'Load'})

# Define a function to draw time_series plot
def timeseries (x_axis, y_axis, x_label):
    plt.figure(figsize = (10, 6))
    plt.plot(x_axis, y_axis, color ='black')
    plt.xlabel(x_label, {'fontsize': 12}) 
    plt.ylabel('Total Grid Load', {'fontsize': 12})
    
dataset = df.copy()
timeseries(df.index, dataset['Load'], 'DateTime')

# Split train data and test data
train_size = int(len(df)*0.7)
train_data = df.iloc[:train_size]
test_data = df.iloc[train_size:]

# Scale data
# The input to scaler.fit -> array-like, sparse matrix, dataframe of shape (n_samples, n_features)
scaler = MinMaxScaler().fit(train_data)
train_scaled = scaler.transform(train_data)
test_scaled = scaler.transform(test_data)

def create_dataset (X, look_back = 1):
    Xs, ys = [], []
    
    for i in range(len(X)-look_back):
        v = X[i:i+look_back]
        Xs.append(v)
        ys.append(X[i+look_back])
        
    return np.array(Xs), np.array(ys)

X_train, y_train = create_dataset(train_scaled,30)
X_test, y_test = create_dataset(test_scaled,30)

print('X_train.shape: ', X_train.shape)
print('y_train.shape: ', y_train.shape)
print('X_test.shape: ', X_test.shape) 
print('y_test.shape: ', y_test.shape)

def create_gru(units):
    model = Sequential()
    # Input layer 
    model.add(GRU (units = units, return_sequences = True, input_shape = [X_train.shape[1], X_train.shape[2]]))
    model.add(Dropout(0.2)) 
    # Hidden layer
    model.add(GRU(units = units))                 
    model.add(Dropout(0.2))
    model.add(Dense(units = 1)) 
    #Compile model
    model.compile(optimizer='adam',loss='mse')
    return model
model_gru = create_gru(64)

early_stop = keras.callbacks.EarlyStopping(monitor = 'val_loss', patience = 10)
history_gru = model_gru.fit(X_train, y_train, epochs = 40, validation_split = 0.2, batch_size = 16, shuffle = False, callbacks = [early_stop])

def plot_loss (history, model_name):
    plt.figure(figsize = (10, 6))
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('Model Train vs Validation Loss for ' + model_name)
    plt.ylabel('Loss')
    plt.xlabel('epoch')
    plt.legend(['Train loss', 'Validation loss'], loc='upper right')
    plt.plot()

plot_loss(history_gru, 'GRU')
y_test = scaler.inverse_transform(y_test)
y_train = scaler.inverse_transform(y_train)

# Make prediction
prediction = model_gru.predict(X_test)
prediction_gru = scaler.inverse_transform(prediction)

# Plot test data vs prediction
def plot_future(prediction, model_name, y_test):
    
    plt.figure(figsize=(10, 6))
    
    range_future = len(prediction)

    plt.plot(np.arange(range_future), np.array(y_test), label='Test data')
    plt.plot(np.arange(range_future), np.array(prediction),label='Prediction')

    plt.title('Test data vs prediction for ' + model_name)
    plt.legend(loc='upper left')
    plt.xlabel('Time (week)')
    plt.ylabel('Total net load')
    plt.show()
       
plot_future(prediction_gru, 'GRU', y_test)

# Calculate MAE and RMSE
def evaluate_prediction(predictions, actual, model_name):
    errors = predictions - actual
    mse = np.square(errors).mean()
    rmse = np.sqrt(mse)
    mae = np.abs(errors).mean()

    print(model_name + ':')
    print('Mean Absolute Error: {:.4f}'.format(mae))
    print('Root Mean Square Error: {:.4f}'.format(rmse))
    print('')

evaluate_prediction(prediction_gru, y_test, 'GRU')

# Scale the input
scaled_data = scaler.transform(df)
# Reshape the input 
def create_dataset (X, look_back = 1):
    Xs = []
    for i in range(len(X)-look_back):
        v = X[i:i+look_back]
        Xs.append(v)
    return np.array(Xs)

X_30= create_dataset(scaled_data,30)
print('X_30.shape: ', X_30.shape) 

# Make prediction for new data
prediction = model_gru.predict(X_30)
prediction = scaler.inverse_transform(prediction)
# Plot history and future
def plot_multi_step(history, prediction1):
    plt.figure(figsize=(15, 6))
    
    range_history = len(history)
    range_future = list(range(range_history, range_history + len(prediction1)))

    plt.plot(np.arange(range_history), np.array(history), label='History')
    plt.plot(range_future, np.array(prediction1),label='Forecasted with GRU')
    
    plt.legend(loc='upper right')
    plt.xlabel('Time step (week)')
    plt.ylabel('Total power load')
    plt.show()
   
plot_multi_step(df, prediction_gru)
